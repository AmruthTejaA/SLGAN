# SLGAN Android app (starter)

Modern Android e-commerce starter for **SLGAN — Sri Lakshmi Ganapathi Ayurvedic Nilayam**.

## Included
- Demo sign-in and editable customer profile
- Product list, product details, add-to-cart, quantity controls, cart total
- Place-order action that generates a text invoice/order request
- Share invoice, open an email composer, or open SMS composer
- Product list and cart work offline during the current app session

## Important before real customers use it
This is a working **starter/demo**, not a production commerce system.
- Product names and prices in `MainActivity.kt` are sample data; confirm and replace them.
- Login is not secure authentication and profile/cart are not persisted between app restarts.
- No server/database, inventory sync, order management, payment gateway, automatic email/SMS sending, or PDF invoice is included. Email/SMS open the user's chosen app and require the user to press Send.
- Replace the placeholder payment text in `MainActivity.kt` with verified business payment instructions. Never put bank passwords, OTPs, or secret API keys in the app.
- Ayurvedic product descriptions must match the approved label and applicable regulations. The sample copy is not medical advice.

## Build an APK locally
Requirements: Android Studio, JDK 17, Android SDK Platform 35, and Gradle 8.9.
1. Open this folder in Android Studio, allow Gradle sync.
2. From the project root run:
   ```bash
   gradle assembleDebug
   ```
3. APK output:
   `app/build/outputs/apk/debug/app-debug.apk`
4. Copy the APK to your Android phone and open it. You may need to allow installation from that file manager.

If Gradle is not installed, open the project in Android Studio and use its Gradle integration.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload this project.
2. Push to `main`/`master`, or open **Actions → Build SLGAN APK → Run workflow**.
3. Open the workflow run and download the `SLGAN-debug-apk` artifact.

## For a production release
Add secure authentication, backend API/database, server-side order IDs, order history, stock/price management, privacy policy, secure payment gateway integration, signed release key, and tested PDF invoice generation. A debug APK is not suitable for Play Store release.
