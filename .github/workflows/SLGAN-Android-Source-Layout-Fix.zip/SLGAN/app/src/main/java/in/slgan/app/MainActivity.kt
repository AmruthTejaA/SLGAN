package in.slgan.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Forest = Color(0xFF176B52)
private val Cream = Color(0xFFF7F7F1)

data class Product(val id: Int, val name: String, val description: String, val price: Int, val category: String)
data class CartLine(val product: Product, val qty: Int)

private val catalog = listOf(
    Product(1, "Rajitha Chandrodayam Pills", "Traditional Ayurvedic product. Check label and directions before use.", 199, "Ayurvedic"),
    Product(2, "Vatha Rasamrutham", "Traditional Ayurvedic product. Check label and directions before use.", 249, "Ayurvedic"),
    Product(3, "Vat Agni Kumara Rasam", "Traditional Ayurvedic product. Check label and directions before use.", 179, "Ayurvedic"),
    Product(4, "Herbal Wellness Pack", "Sample listing — replace with your actual product details.", 299, "Wellness")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SlganApp() }
    }
}

@Composable
fun SlganApp() {
    val context = LocalContext.current
    var signedIn by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("Shop") }
    var selected by remember { mutableStateOf<Product?>(null) }
    val cart = remember { mutableStateListOf<CartLine>() }
    var lastInvoice by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    val total = cart.sumOf { it.product.price * it.qty }

    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Color(0xFFC28A36), background = Cream)) {
        Surface(Modifier.fillMaxSize(), color = Cream) {
            if (!signedIn) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                    Text("SLGAN", fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, color = Forest)
                    Text("Sri Lakshmi Ganapathi Ayurvedic Nilayam", color = Color.DarkGray)
                    Spacer(Modifier.height(24.dp))
                    Text("Welcome", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Demo sign-in — no password or real account is created.")
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(name, { name = it }, label = { Text("Your name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(email, { email = it }, label = { Text("Email (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(phone, { phone = it }, label = { Text("Phone (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { if (name.isNotBlank()) signedIn = true }, modifier = Modifier.fillMaxWidth()) { Text("Continue") }
                    Text("Products and cart are stored in memory for this demo. Add a secure backend before public launch.", fontSize = 12.sp, color = Color.Gray)
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().background(Forest).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("SLGAN", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                            Text("Ayurvedic Nilayam", color = Color.White.copy(alpha = .8f), fontSize = 12.sp)
                        }
                        TextButton(onClick = { page = "Cart" }) {
                            Icon(Icons.Default.ShoppingCart, null, tint = Color.White)
                            Text(" ${cart.sumOf { it.qty }}", color = Color.White)
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        if (selected != null) {
                            ProductDetails(selected!!, onBack = { selected = null }, onAdd = {
                                val p = selected!!
                                val i = cart.indexOfFirst { it.product.id == p.id }
                                if (i >= 0) cart[i] = cart[i].copy(qty = cart[i].qty + 1) else cart.add(CartLine(p, 1))
                                status = "${p.name} added to cart"
                            })
                        } else {
                            when (page) {
                            "Cart" -> CartPage(cart, total, onQty = { p, delta ->
                                val i = cart.indexOfFirst { it.product.id == p.id }
                                if (i >= 0) { val q = cart[i].qty + delta; if (q <= 0) cart.removeAt(i) else cart[i] = cart[i].copy(qty = q) }
                            }, onCheckout = {
                                if (cart.isEmpty()) status = "Your cart is empty"
                                else {
                                    val orderId = "SLGAN-" + System.currentTimeMillis().toString().takeLast(7)
                                    val date = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                                    lastInvoice = buildString {
                                        appendLine("SLGAN — Sri Lakshmi Ganapathi Ayurvedic Nilayam")
                                        appendLine("INVOICE / ORDER: $orderId")
                                        appendLine("Date: $date")
                                        appendLine("Customer: $name")
                                        appendLine("Phone: $phone")
                                        appendLine("--------------------------------")
                                        cart.forEach { appendLine("${it.product.name} x${it.qty}  ₹${it.product.price * it.qty}") }
                                        appendLine("--------------------------------")
                                        appendLine("Total: ₹$total")
                                        appendLine("Payment: Pay on confirmation / configure your real payment details")
                                        appendLine("Bank/UPI details: UPDATE IN MainActivity.kt before launch")
                                        appendLine("Order is a request only; payment has not been collected.")
                                    }
                                    status = "Order request prepared. Choose message or email to send it."
                                }
                            })
                            "Profile" -> ProfilePage(name, email, phone, { name = it }, { email = it }, { phone = it }, { signedIn = false })
                            "Orders" -> OrdersPage(lastInvoice, onShare = { shareText(context, lastInvoice) })
                            else -> ProductList(catalog, onSelect = { selected = it }, onAdd = { p ->
                                val i = cart.indexOfFirst { it.product.id == p.id }
                                if (i >= 0) cart[i] = cart[i].copy(qty = cart[i].qty + 1) else cart.add(CartLine(p, 1))
                                status = "${p.name} added to cart"
                            })
                            }
                        }
                    }
                    if (status.isNotBlank()) {
                        Surface(color = Color(0xFFE4EFE8), modifier = Modifier.fillMaxWidth()) {
                            Text(status, Modifier.padding(10.dp), color = Forest, fontSize = 13.sp)
                        }
                    }
                    NavigationBar(containerColor = Color.White) {
                        listOf("Shop", "Cart", "Orders", "Profile").forEach { item ->
                            NavigationBarItem(selected = page == item && selected == null, onClick = { selected = null; page = item }, icon = {
                                Icon(when(item) { "Shop" -> Icons.Default.Storefront; "Cart" -> Icons.Default.ShoppingCart; "Orders" -> Icons.Default.ReceiptLong; else -> Icons.Default.Person }, contentDescription = item)
                            }, label = { Text(item) })
                        }
                    }
                    if (lastInvoice.isNotBlank() && page == "Cart") {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { shareText(context, lastInvoice) }, modifier = Modifier.weight(1f)) { Text("Share invoice") }
                            Button(onClick = { sendEmail(context, email, lastInvoice) }, modifier = Modifier.weight(1f)) { Text("Email order") }
                            Button(onClick = { sendSms(context, phone, lastInvoice) }, modifier = Modifier.weight(1f)) { Text("Message") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ColumnScope.ProductList(products: List<Product>, onSelect: (Product) -> Unit, onAdd: (Product) -> Unit) {
    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Discover our products", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Browse the catalogue and add items to your cart.")
        }
        items(products) { p ->
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(62.dp).background(Color(0xFFE4EFE8), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Spa, null, tint = Forest, modifier = Modifier.size(34.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text(p.category, color = Forest, fontSize = 12.sp)
                            Text("₹${p.price}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(p.description, Modifier.padding(top = 10.dp), fontSize = 13.sp, color = Color.DarkGray)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onSelect(p) }, modifier = Modifier.weight(1f)) { Text("Details") }
                        Button(onClick = { onAdd(p) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AddShoppingCart, null); Spacer(Modifier.width(4.dp)); Text("Add to cart") }
                    }
                }
            }
        }
    }
}

@Composable
fun ProductDetails(p: Product, onBack: () -> Unit, onAdd: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Text(" Back to shop") }
        Box(Modifier.fillMaxWidth().height(150.dp).background(Color(0xFFE4EFE8), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Spa, null, tint = Forest, modifier = Modifier.size(80.dp))
        }
        Spacer(Modifier.height(18.dp))
        Text(p.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("₹${p.price}", style = MaterialTheme.typography.titleLarge, color = Forest, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(p.description)
        Spacer(Modifier.height(12.dp))
        Text("Product information", fontWeight = FontWeight.Bold)
        Text("Replace this sample description with the approved product label, ingredients, pack size, directions, and applicable warnings.")
        Spacer(Modifier.weight(1f))
        Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AddShoppingCart, null); Text("  Add to cart") }
    }
}

@Composable
fun CartPage(cart: List<CartLine>, total: Int, onQty: (Product, Int) -> Unit, onCheckout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Your cart", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (cart.isEmpty()) {
            Spacer(Modifier.height(18.dp)); Text("Your cart is empty. Visit Shop to add products.")
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(cart) { line ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(line.product.name, fontWeight = FontWeight.SemiBold); Text("₹${line.product.price} each") }
                            IconButton(onClick = { onQty(line.product, -1) }) { Icon(Icons.Default.Remove, "Decrease quantity") }
                            Text("${line.qty}")
                            IconButton(onClick = { onQty(line.product, 1) }) { Icon(Icons.Default.Add, "Increase quantity") }
                        }
                    }
                }
            }
            Text("Total: ₹$total", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Button(onClick = onCheckout, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.ReceiptLong, null); Text("  Place order & create invoice") }
            Text("This demo creates an order request only. It does not charge a payment.", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun ProfilePage(name: String, email: String, phone: String, onName: (String) -> Unit, onEmail: (String) -> Unit, onPhone: (String) -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Your profile", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(name, onName, label = { Text("Name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(email, onEmail, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, onPhone, label = { Text("Phone") }, modifier = Modifier.fillMaxWidth())
        Text("Profile details remain in app memory in this demo.", fontSize = 12.sp, color = Color.Gray)
        OutlinedButton(onClick = onLogout) { Text("Sign out") }
    }
}

@Composable
fun OrdersPage(invoice: String, onShare: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Orders & invoices", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (invoice.isBlank()) Text("No order yet. Place an order from your cart to create an invoice.")
        else {
            Text("Latest order invoice", fontWeight = FontWeight.Bold)
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Text(invoice, Modifier.padding(14.dp), fontSize = 13.sp) }
            Spacer(Modifier.height(12.dp))
            Button(onClick = onShare) { Icon(Icons.Default.Share, null); Text("  Share invoice") }
        }
    }
}

private fun shareText(context: android.content.Context, text: String) {
    if (text.isBlank()) return
    val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "SLGAN order invoice"); putExtra(Intent.EXTRA_TEXT, text) }
    context.startActivity(Intent.createChooser(intent, "Share invoice"))
}
private fun sendEmail(context: android.content.Context, customerEmail: String, body: String) {
    if (body.isBlank()) return
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("mailto:")
        if (customerEmail.isNotBlank()) putExtra(Intent.EXTRA_EMAIL, arrayOf(customerEmail))
        putExtra(Intent.EXTRA_SUBJECT, "SLGAN order and invoice")
        putExtra(Intent.EXTRA_TEXT, body)
    }
    context.startActivity(Intent.createChooser(intent, "Email order details"))
}
private fun sendSms(context: android.content.Context, phone: String, body: String) {
    if (body.isBlank()) return
    val intent = Intent(Intent.ACTION_SENDTO).apply {
        data = Uri.parse("smsto:${Uri.encode(phone)}")
        putExtra("sms_body", body)
    }
    context.startActivity(Intent.createChooser(intent, "Send order message"))
}
